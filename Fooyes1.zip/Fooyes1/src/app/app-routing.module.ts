import {  NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { AddressComponent } from './restaurant-details/address/address.component';
import { CartComponent } from './restaurant-details/cart/cart.component';
import { RestaurantListComponent } from './restaurant-details/restaurant-list/restaurant-list.component';
import { RestaurantComponent } from './restaurant-details/restaurant/restaurant.component';
import { SignupComponent } from './signup/signup.component';

const routes: Routes = [
  {
    path:'',
    component:HomeComponent
  },{
    path:'signup',
    component:SignupComponent
  },{
    path:'*',
    component:NotFoundComponent
  }
  ,{
    path:'restaurant-list',
    component:RestaurantListComponent
  }
  ,{
    path:'address',
    component:AddressComponent
  },{
    path:'restaurant/:id',
    component:RestaurantComponent
  },{
    path:'cart',
    component:CartComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
