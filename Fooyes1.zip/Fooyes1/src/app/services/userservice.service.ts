import { HttpClient } from '@angular/common/http';
import { EventEmitter, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class UserserviceService {

  isUserLoggedIn=new BehaviorSubject<boolean>(false);
  islogginError=new EventEmitter<boolean>(false);
  constructor(private http:HttpClient,private router:Router) { }

  url="http://localhost:8082/api/user"
  saveuser(data:any){
    return this.http.post(this.url,data,{observe:'response'}).subscribe((result)=>{
      if(result){
        this.isUserLoggedIn.next(true);
        localStorage.setItem('user',JSON.stringify(result.body));
        this.router.navigate(['/']) ;  
      }
    })
  }
  getuser(data:any){
    console.log(data);
    
    return this.http.get(`http://localhost:8082/api/user?email=${data.email}&password=${data.password}`,{observe:'response'}).subscribe((result:any)=>{
      console.log(result.body);
      
      if(result && result.body){
        localStorage.setItem('user',JSON.stringify(result.body));
        this.router.navigate(['/']) ;  
      }
      else{
       this.islogginError.emit(true);
      }

    })

  }
  reloadSeller(){
    if(localStorage.getItem('user')){
      this.isUserLoggedIn.next(true);
      this.router.navigate(['/']) ;  

    }
  }
  AddAddress(data:any){
    return this.http.post(`http://localhost:8082/api/address`,data);
  }
}
