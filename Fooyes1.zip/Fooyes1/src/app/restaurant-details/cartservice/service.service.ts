import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  url="http://localhost:8082/api/cart";

   cartItemList:any=[];
   productList=new BehaviorSubject<any>([]);
  constructor(private route:Router,private http: HttpClient) { }
     getproducts(){
      return this.productList.asObservable();
     }

     setProduct(product:any){
      this.cartItemList.push(...product);
      this.productList.next(product);
}
  addtocart(item:any){
    this.http.post(this.url,item,{observe:'response'}).subscribe((result)=>{
         console.log(result);    
    })
    this.cartItemList.push(item);
    this.productList.next(this.cartItemList);
    this.getTotalPrice();
    console.log(this.cartItemList);
    console.log(this.productList);
    
    // this.route.navigate(['cart']);
    
  }
  getTotalPrice():number{
    let grandTotal=0;
    this.cartItemList.map((a:any)=>{
      grandTotal+=a.total;
    })
    return grandTotal;
  }
  removeCartItem(product:any){
    this.http.delete(`http://localhost:8082/api/cart/${product.id}`).subscribe((result)=>{
       alert("deleted successfully");
    })
    this.cartItemList.map((a:any,index:any)=>{
      if(product.id===a.id){
     this.cartItemList.splice(index,1);
      }
    })
  }
  removeAllCart(){
  
    this.cartItemList=[]
    this.productList.next(this.cartItemList)
  }
}
