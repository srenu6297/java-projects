import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RestaurantListComponent } from "./restaurant-list/restaurant-list.component";
import { AddressComponent } from './address/address.component';
import { RestaurantComponent } from './restaurant/restaurant.component';
import { HttpClientModule  } from "@angular/common/http";
import { NgxPaginationModule } from "ngx-pagination";
import { FontAwesomeModule } from "@fortawesome/angular-fontawesome";
import { ReactiveFormsModule } from "@angular/forms";
import { CartComponent } from './cart/cart.component';
@NgModule({
  declarations: [
    RestaurantListComponent,
    AddressComponent,
    RestaurantComponent,
    CartComponent,
  ],
  imports: [
    CommonModule ,HttpClientModule,NgxPaginationModule,FontAwesomeModule,ReactiveFormsModule
  ],
  exports:[
    RestaurantListComponent,
    AddressComponent
  ]
})
export class RestaurantDetailsModule { }
