import { Component } from '@angular/core';  
import { FormGroup,FormControl ,Validators } from "@angular/forms";
import { Router } from '@angular/router';
import { UserserviceService } from 'src/app/services/userservice.service';

@Component({
  selector: 'app-address',
  templateUrl: './address.component.html',
  styleUrls: ['./address.component.css']
})
export class AddressComponent {

  constructor(private userdata:UserserviceService,private router:Router) {
    
  }

  addressform=new FormGroup({
    villortown: new FormControl('',[Validators.required]),
    state:new FormControl('',[Validators.required]),
    city:new FormControl('',[Validators.required]),
    number:new FormControl('',[Validators.required]),
    landmark:new FormControl('',[Validators.required]),
    pincode:new FormControl('',[Validators.required])

  })
  
  address(value:any){
     console.log(value);
    var user = JSON.parse(localStorage.getItem('user')+'');
    //@ts-ignore
    value.userId = user.id;
     this.userdata.AddAddress(value).subscribe((result)=>{
      console.log(result);
      this.router.navigate(['/restaurant-list']) ;  
     })
     
  }

}
