import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { RestaurantService } from '../restaurant.service';
import { faMinus, faPlus } from "@fortawesome/free-solid-svg-icons";
import { ServiceService } from '../cartservice/service.service';

@Component({
  selector: 'app-restaurant',
  templateUrl: './restaurant.component.html',
  styleUrls: ['./restaurant.component.css']
})
export class RestaurantComponent {
  hotel: any;
  constructor(private userdata: RestaurantService, private Activateroute: ActivatedRoute,private cart:ServiceService) { }
  plus = faPlus;
  minus = faMinus;


  ngOnInit(): void {
    let hotelid = this.Activateroute.snapshot.paramMap.get('id');
    // console.log(hotelid);
    this.userdata.hotel(hotelid).subscribe((result) => {

      console.log(result);
      this.hotel = result;
      this.hotel.subcat.pro.forEach((a:any)=>{
        Object.assign(a,{quantity:1,total:a.price})
      })

      var count = 1;
      this.hotel.subcat.forEach((subcat: any) => {
        subcat.pro.forEach((product: any) => {
          product.index = count;
          count++;
        });
      });

    })
  }
  

  addtocart(J:any){
    var user = JSON.parse(localStorage.getItem('user')+'');
    //@ts-ignore
    J.userId = user.id;
  this.cart.addtocart(J);
  }



}
