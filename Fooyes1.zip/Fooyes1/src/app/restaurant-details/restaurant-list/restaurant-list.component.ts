import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { faRightToBracket } from '@fortawesome/free-solid-svg-icons';
import { RestaurantService } from '../restaurant.service';

@Component({
  selector: 'app-restaurant-list',
  templateUrl: './restaurant-list.component.html',
  styleUrls: ['./restaurant-list.component.css']
})
export class RestaurantListComponent {
  MenuType:string='default';
  hotellist:any;
  userAddress:any;
  changebutton:string=''
  out=faRightToBracket
  constructor(private router:Router,private userdata:RestaurantService){
    this.userdata.hotellist().subscribe((result)=>{
      console.log(result);
       this.hotellist=result;   
    })
  }
  ngOnInit(){
        if(localStorage.getItem('user')!=null){
          this.MenuType='user';
            let userStore=localStorage.getItem('user');
            let userData=userStore && JSON.parse(userStore);

            if(userData?.add?.length > 0){
              this.userAddress = userData?.add[0];
              this.changebutton='Change address'
            }else{
              this.changebutton='Add address'
            }
        }
        else{
          this.MenuType='default';
        }
  }



  distance:any;
  valuechange(data:any){
    this.distance=data.target.value;
  }

}
