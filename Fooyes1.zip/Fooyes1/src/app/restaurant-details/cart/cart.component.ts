import { Component } from '@angular/core';
import { ServiceService } from '../cartservice/service.service';
import { faTrashCan } from "@fortawesome/free-regular-svg-icons";
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent {

  remove=faTrashCan;
  product:any=[];
  grandTotal!:number;

  constructor(private cart: ServiceService,private route:Router) {
  
    
  }
  ngOnInit():void{
    this.cart.getproducts().subscribe((res)=>{
      this.product=res;
      this.grandTotal=this.cart.getTotalPrice();
    })
  }
  removeitem(item:any){
    console.log(item);
    this.cart.removeCartItem(item);
  }
  emptyCart(){
    this.cart.removeAllCart();
  }
  move(){
    this.route.navigate(['restaurant-list']);
  }
  placeOder(){
      alert("your order is placed succesfully");
      this.emptyCart();
  }


}
