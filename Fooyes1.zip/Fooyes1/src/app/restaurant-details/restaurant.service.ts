import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class RestaurantService {

  constructor(private http:HttpClient) { }
  url = 'http://localhost:8082/api/category';
  hotellist() {
    return this.http.get(this.url);
  }
  hotel(id:any){
    return this.http.get(`http://localhost:8082/api/category?id=${id}`)
  }
}
