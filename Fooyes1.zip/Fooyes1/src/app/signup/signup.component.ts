import { Component } from '@angular/core';
import { FormGroup,FormControl,Validators } from "@angular/forms";
import { Router } from '@angular/router';
import { UserserviceService } from '../services/userservice.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {

  showError:string='';

  constructor(private router:Router,private userdata:UserserviceService){}
  ngOnInit():void{
    this.userdata.reloadSeller();
  }
  showform=false;
      showsignupform(){
        this.showform=false;
      }
      showloginform(){
        this.showform=true;
      }
      signupform= new FormGroup({
        name: new FormControl('',[Validators.required,Validators.minLength(5)]),
        number:new FormControl('',[Validators.required,Validators.minLength(10),Validators.maxLength(10)]),
        email:new FormControl('',[Validators.required,Validators.email]),
        password:new FormControl('',[Validators.required,Validators.minLength(8)]),
        confirm_password:new FormControl('',[Validators.required])
      })
      loginform= new FormGroup({
        email:new FormControl('',[Validators.required,Validators.email]),
        password:new FormControl('',[Validators.required,Validators.minLength(8)])
      })
      signup(value:any){
        this.userdata.saveuser(value);  
      }
      login(value:any){
        this.showError="";
        this.userdata.getuser(value);
        this.userdata.islogginError.subscribe((res)=>{
         if(res){
         this.showError=" * Either Email or Password is not"
         }
        })
      }
      get name(){
        return this.signupform.get('name');
      }
      get number(){
        return this.signupform.get('number');
      }
      get email(){
        return this.signupform.get('email');
      }
      get password(){
        return this.signupform.get('password');
      }
      get email1(){
        return this.loginform.get('email');
      }
      get password1(){
        return this.loginform.get('password');
      }
     get confirm_password(){
      return this.loginform.get('confirm_password');
     }

}
