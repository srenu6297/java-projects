import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { RestaurantService } from '../restaurant-details/restaurant.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  
  hotellist:any;
  constructor(private router:Router,private userdata:RestaurantService){
    this.userdata.hotellist().subscribe((result)=>{
      console.log(result);
       this.hotellist=result;   
    })
  }

}
